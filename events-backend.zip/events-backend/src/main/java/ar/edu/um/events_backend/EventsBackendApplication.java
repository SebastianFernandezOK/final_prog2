package ar.edu.um.events_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsBackendApplication.class, args);
	}

}
